# Food Order
Responsive webpage design using plan HTML and CSS 

# Installation

1.  Clone or Download the repository

```bash
    git clone https://github.com/aravindDBhat/OrderFood.git
```
# How it works

- [live](https://order-food-theta.vercel.app/)
